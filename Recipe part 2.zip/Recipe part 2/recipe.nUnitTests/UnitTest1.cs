namespace RecipeAppTests
{
    using Microsoft.VisualStudio.TestPlatform.TestHost;
    using RecipeAppTests;
    [TestFixture]
    public class RecipeTests
    {
        [Test]
        public void CalculateTotalCalories_ShouldReturnCorrectTotal()
        {
            // Arrange
            Recipe recipe = new Recipe();
            Program program = new Program();
            
            recipe.AddIngredient("Ingredient 1", 100, "g", 50, "Food Group A");
            recipe.AddIngredient("Ingredient 2", 200, "g", 80, "Food Group B");

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(130, totalCalories); 

            
            
            
        }
    }
}
