﻿
namespace RecipeAppTests
{
    internal class Recipe
    {
        internal void AddIngredient(string v1, int v2, string v3, int v4, string v5)
        {
            throw new NotImplementedException();
        }

        internal int CalculateTotalCalories()
        {
            throw new NotImplementedException();
        }
    }
}