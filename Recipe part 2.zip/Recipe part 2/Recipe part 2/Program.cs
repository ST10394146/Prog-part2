﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    // Main program class
    class Program
    {
        public delegate string myDelegate(double calory);
        static void Main(string[] args)
        {
            // List to store recipes
            List<Recipe> recipes = new List<Recipe>();

            while (true)
            {
                // Display menu options
               
                Console.WriteLine("\nChoose Options:");
                Console.WriteLine("1. Add Recipe");
                Console.WriteLine("2. Display Recipes");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear All Data");
                Console.WriteLine("6. Exit");
                
                string option = Console.ReadLine();

                // Perform actions based on user input
                switch (option)
                {
                    case "1":
                        // Add a new recipe
                        Recipe newRecipe = CreateRecipe();
                        recipes.Add(newRecipe);
                        break;
                    case "2":
                        // View all recipes
                        if (recipes.Count == 0)
                        {
                            Console.WriteLine("No recipes available.");
                        }
                        else
                        {
                            ViewRecipes(recipes);
                        }
                        break;
                    case "3":
                        // Scale a recipe
                        if (recipes.Count == 0)
                        {
                            Console.WriteLine("No recipes available to scale.");
                        }
                        else
                        {
                            ScaleRecipe(recipes);
                        }
                        break;
                    case "4":
                        // Reset quantities of a recipe
                        if (recipes.Count == 0)
                        {
                            Console.WriteLine("No recipes available to reset quantities.");
                        }
                        else
                        {
                            ResetQuantities(recipes);
                        }
                        break;
                    case "5":
                        // Clear all data
                        recipes.Clear();
                        Console.WriteLine("All data cleared.");
                        break;
                    case "6":
                        // Exit the program
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please select a valid option.");
                        break;
                }
            }
        }

        // Method to create a new recipe
        static Recipe CreateRecipe()
        {
            Recipe recipe = new Recipe();

            // Prompt user to enter recipe name
            Console.Write("Enter recipe name: ");
            string name = Console.ReadLine();
            recipe.Name = name;

            // Prompt user to enter ingredient details
            Console.Write("Enter number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Loop to input ingredient details
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Ingredient {i + 1}:");
                Console.Write("Name: ");
                string ingredientName = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                string unit = Console.ReadLine();
                Console.Write("Calories: ");
                int calories = int.Parse(Console.ReadLine());
                Console.Write("Food Group: ");
                string foodGroup = Console.ReadLine();

                // Add ingredient to the recipe
                recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
            }

            // Prompt user to enter steps details
            Console.Write("Number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            // Loop to input step details
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Step {i + 1}:");
                Console.Write("Description of what to do: ");
                string stepDescription = Console.ReadLine();

                // Add step to the recipe
                recipe.AddStep(stepDescription);
            }

            return recipe;
        }

        // Method to view all recipes
        static void ViewRecipes(List<Recipe> recipes)
        {
            myDelegate del = caloryWarning;
            // Sort recipes by name
            recipes = recipes.OrderBy(r => r.Name).ToList();

            // Display list of recipes
            Console.WriteLine("Recipes:");
            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            // Prompt user to choose a recipe
            Console.Write("Select a recipe number to display details: ");
            int selectedRecipeIndex = int.Parse(Console.ReadLine()) - 1;

            // Display recipe details
            if (selectedRecipeIndex >= 0 && selectedRecipeIndex < recipes.Count)
            {
                Recipe selectedRecipe = recipes[selectedRecipeIndex];
                Console.WriteLine(selectedRecipe.GetRecipeDetails());

                // Calculate total calories
                int totalCalories = selectedRecipe.CalculateTotalCalories();
                Console.WriteLine($"Total Calories: {totalCalories}");

                // Notify user if total calories exceed 300
                Console.WriteLine(del.Invoke(totalCalories));
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }
        public static string caloryWarning(double calories)
        {
            string cal = "";
            if (calories >= 300)
            {
                cal = "Warning: Total calories of this recipe exceed 300!";
            }
            return cal;
        }


        // Method to scale a recipe
        static void ScaleRecipe(List<Recipe> recipes)
        {
            Console.Write("Select a recipe number to scale: ");
            int selectedRecipeIndex = int.Parse(Console.ReadLine()) - 1;

            if (selectedRecipeIndex >= 0 && selectedRecipeIndex < recipes.Count)
            {
                Recipe selectedRecipe = recipes[selectedRecipeIndex];
                Console.Write("Enter scale factor (0.5, 2, or 3): ");
                double factor = double.Parse(Console.ReadLine());
                selectedRecipe.ScaleRecipe(factor);
                Console.WriteLine("Recipe scaled successfully.");
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }


        // Method to reset quantities of a recipe
        static void ResetQuantities(List<Recipe> recipes)
        {
            Console.Write("Select a recipe number to reset quantities: ");
            int selectedRecipeIndex = int.Parse(Console.ReadLine()) - 1;

            if (selectedRecipeIndex >= 0 && selectedRecipeIndex < recipes.Count)
            {
                Recipe selectedRecipe = recipes[selectedRecipeIndex];
                selectedRecipe.ResetQuantities();
                Console.WriteLine("Quantities reset to original values.");
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }
    }

    // Recipe class
    class Recipe
    {
        // Properties
        public string Name { get; set; }
        private List<Ingredient> ingredients = new List<Ingredient>();
        private List<string> steps = new List<string>();

        // Method to calculate the total calorie of all ingredients
        public int CalculateTotalCalories()
        {
            int totalCalories = 0;
            foreach (var ingredient in ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }

        // Method to add an ingredient to the recipe
        public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            Ingredient ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
            ingredients.Add(ingredient);
        }

        // Method to add a step to the recipe
        public void AddStep(string description)
        {
            steps.Add(description);
        }

        // Method to get the full recipe details
        public string GetRecipeDetails()
        {
            string details = $"Recipe: {Name}\n\n";
            details += "Ingredients:\n";
            foreach (var ingredient in ingredients)
            {
                details += $"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} - {ingredient.Calories} calories - {ingredient.FoodGroup}\n";
            }
            details += "\nSteps:\n";
            for (int i = 0; i < steps.Count; i++)
            {
                details += $"{i + 1}. {steps[i]}\n";
            }
            return details;
        }

        // Method to scale the recipe by a factor
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        // Method to reset quantities to original values
        public void ResetQuantities()
        {
            
        }
    }

    // Ingredient class
    class Ingredient
    {
        // Properties
        public string Name { get; }
        public double Quantity { get; set; }
        public string Unit { get; }
        public int Calories { get; }
        public string FoodGroup { get; }

        // Constructor to initialize ingredient properties
        public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}
